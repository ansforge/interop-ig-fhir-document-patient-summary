# ans.fhir.fr.fr-patient-summary#0.1.0: FR Patient Summary (FHIR)(fr)

## Pages

* [Accueil](index.md)
* [Téléchargements et usages](annexe-downloads.md)
* [FHIR](fhir.md)
* [Informations sur la traduction](translationinfo.md)
* [Mapping ML/CDA/FHIR](mapping.md)
* [Modèle logique métier](modele-logique-metier.md)
* [Résumé des artefacts](artifacts.md)
* [Fonctionnel](fonctionnel.md)
* [Cas d'usage](cas-usage.md)
* [Autres Ressources](autres_ressources.md)
* [Exigences spécifiques](exigences-specifiques.md)
* [Sécurité](securite.md)
* [Implémentations](implementations.md)

## Resources

### Logicals

* [Modèle logique métier - FR LM Patient Summary Document](StructureDefinition-fr-lm-patient-summary-document.md)

### Resource Profiles

* [Bundle (IPS)](StructureDefinition-fr-bundle-document-ips.md)
* [FR Composition Document IPS](StructureDefinition-fr-composition-document-ips.md)

### ImplementationGuides

* [FR Patient Summary (FHIR)](ImplementationGuide-ans.fhir.fr.fr-patient-summary.md)

### Examples

* [Bundle-IPS-FR-DLU (Bundle)](Bundle-Bundle-IPS-FR-DLU.md)
* [Bundle-IPS-FR (Bundle)](Bundle-Bundle-IPS-FR.md)
