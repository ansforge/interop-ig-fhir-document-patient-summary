# Autres Ressources - FR Patient Summary (FHIR) v0.1.0

## Autres Ressources

 
There is no translation page available for the current page, so it has been rendered in the default language 

* [Téléchargements et usage](./annexe-downloads.md)
* [Spécifications FHIR](http://hl7.org/fhir/R4/index.html)
* [Site de l'ANS](https://esante.gouv.fr/)

