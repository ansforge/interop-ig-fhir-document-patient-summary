# Vue d'ensemble - FR Patient Summary (FHIR) v0.1.0

## Vue d'ensemble

 
There is no translation page available for the current page, so it has been rendered in the default language 

### Introduction spécifications fonctionnelles

Introduction specs fonctionnelles

