# Modèle logique métier - Volet de Synthèse Médicale (International Patient Summary - FHIR) v0.1.0

## Modèle logique métier

Ce modèle logique décrit la structuration d'un document de synthèse médicale rassemblant les informations de santé les plus importantes d'un patient, dans un objectif de conformité avec la norme ISO International Patient Summary (IPS).

Le modèle logique métier couvre :

* [Modèle logique - Document Patient Summary](../StructureDefinition-fr-lm-patient-summary-document.md)

